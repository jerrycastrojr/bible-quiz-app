# biblequiz

A Pen created on CodePen.io. Original URL: [https://codepen.io/Jerry-Castro-the-reactor/pen/YzmmQvE](https://codepen.io/Jerry-Castro-the-reactor/pen/YzmmQvE).

